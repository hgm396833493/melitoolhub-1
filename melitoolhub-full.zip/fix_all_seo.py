import os
import re
from datetime import datetime

BASE_URL = 'https://melitoolhub.com'
TODAY = datetime.now().strftime('%Y-%m-%d')

# ========== 1. 更新 sitemap.xml ==========
with open('sitemap.xml', 'r', encoding='utf-8') as f:
    sitemap = f.read()

# 获取所有 HTML 文件（排除模板）
html_files = sorted([f for f in os.listdir('.') if f.endswith('.html') and f not in ['article-template.html', 'policy-template.html']])

page_info = {
    'index.html': {'freq': 'weekly', 'priority': '1.0', 'is_home': True, 'desc': '首页'},
    'article-meli-es.html': {'freq': 'monthly', 'priority': '0.9', 'desc': '美客多开店教程'},
    'article-latam-logistics-es.html': {'freq': 'monthly', 'priority': '0.9', 'desc': '拉美物流对比'},
    'article-brazil-market.html': {'freq': 'monthly', 'priority': '0.8', 'desc': '巴西市场准入'},
    'article-mexico-customs.html': {'freq': 'monthly', 'priority': '0.8', 'desc': '墨西哥海关'},
    'article-payment-comparison.html': {'freq': 'monthly', 'priority': '0.8', 'desc': '跨境支付对比'},
    'article-mercado-libre-es.html': {'freq': 'monthly', 'priority': '0.8', 'desc': 'Mercado Libre攻略'},
    'tools.html': {'freq': 'monthly', 'priority': '0.8', 'desc': '工具专区'},
    'sourcing.html': {'freq': 'monthly', 'priority': '0.9', 'desc': '采购代办服务'},
    'news1.html': {'freq': 'monthly', 'priority': '0.7', 'desc': '政策资讯'},
    'news2.html': {'freq': 'monthly', 'priority': '0.7', 'desc': '政策资讯'},
    'article-latam-products.html': {'freq': 'monthly', 'priority': '0.7', 'desc': '拉美选品指南'},
    'article-meli-ads.html': {'freq': 'monthly', 'priority': '0.7', 'desc': '美客多广告攻略'},
    'article-latam-packaging.html': {'freq': 'monthly', 'priority': '0.7', 'desc': '拉美包装规范'},
    'article-overseas-warehouse.html': {'freq': 'monthly', 'priority': '0.7', 'desc': '海外仓指南'},
    'article-tiktok-latam.html': {'freq': 'monthly', 'priority': '0.7', 'desc': 'TikTok拉美电商'},
    'cooperation.html': {'freq': 'monthly', 'priority': '0.6', 'desc': '合作与结算说明'},
    'privacy.html': {'freq': 'yearly', 'priority': '0.3', 'desc': '隐私政策'},
    '404.html': {'freq': 'yearly', 'priority': '0.1', 'desc': '404错误页'},
}

# 构建新 sitemap
hreflangs = [
    ('zh-CN', '/'), ('en', '/?lang=en'), ('es', '/?lang=es'), ('pt', '/?lang=pt'),
    ('ru', '/?lang=ru'), ('fr', '/?lang=fr'), ('de', '/?lang=de'), ('it', '/?lang=it'),
    ('ar', '/?lang=ar'), ('tr', '/?lang=tr'), ('vi', '/?lang=vi'), ('th', '/?lang=th'),
    ('id', '/?lang=id'), ('ms', '/?lang=ms'), ('ko', '/?lang=ko'), ('ja', '/?lang=ja'),
    ('pl', '/?lang=pl'), ('nl', '/?lang=nl'), ('x-default', '/')
]

sitemap_lines = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"',
    '        xmlns:xhtml="http://www.w3.org/1999/xhtml">',
    ''
]

for f in html_files:
    info = page_info.get(f, {'freq': 'monthly', 'priority': '0.5', 'desc': f.replace('.html', '')})
    path = '/' if f == 'index.html' else f
    loc = BASE_URL + path
    
    sitemap_lines.append(f'  <!-- {info["desc"]} -->')
    sitemap_lines.append('  <url>')
    sitemap_lines.append(f'    <loc>{loc}</loc>')
    
    # 首页添加 hreflang
    if info.get('is_home'):
        for lang, href in hreflangs:
            sitemap_lines.append(f'    <xhtml:link rel="alternate" hreflang="{lang}" href="{BASE_URL}{href}"/>')
    
    sitemap_lines.append(f'    <lastmod>{TODAY}</lastmod>')
    sitemap_lines.append(f'    <changefreq>{info["freq"]}</changefreq>')
    sitemap_lines.append(f'    <priority>{info["priority"]}</priority>')
    sitemap_lines.append('  </url>')
    sitemap_lines.append('')

sitemap_lines.append('</urlset>')

with open('sitemap.xml', 'w', encoding='utf-8') as f:
    f.write('\n'.join(sitemap_lines))

print(f'[UPDATED] sitemap.xml - {len(html_files)} pages, lastmod: {TODAY}')

# ========== 2. 优化 robots.txt ==========
robots_content = f"""# GlobalTradeHub robots.txt
# {BASE_URL}/robots.txt

User-agent: *
Allow: /
Disallow: /admin/
Disallow: /private/
Disallow: /404.html

# Sitemap
Sitemap: {BASE_URL}/sitemap.xml

# Crawl-delay (seconds between requests)
Crawl-delay: 1
"""

with open('robots.txt', 'w', encoding='utf-8') as f:
    f.write(robots_content)

print(f'[UPDATED] robots.txt')

# ========== 3. 为缺少 Twitter Card 的文件添加 ==========
files_need_twitter = [
    'article-brazil-market.html', 'article-latam-packaging.html', 'article-latam-products.html',
    'article-meli-ads.html', 'article-mexico-customs.html', 'article-overseas-warehouse.html',
    'article-payment-comparison.html', 'article-tiktok-latam.html', 'cooperation.html',
    'policy-template.html', 'privacy.html', 'sourcing.html', 'tools.html'
]

# 获取每个文件的实际标题和描述
def extract_meta(file):
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()
    title_match = re.search(r'<title>([^<]+)</title>', content)
    desc_match = re.search(r'<meta[^>]*name="description"[^>]*content="([^"]+)"', content)
    og_img = re.search(r'<meta[^>]*property="og:image"[^>]*content="([^"]+)"', content)
    return {
        'title': title_match.group(1) if title_match else 'GlobalTradeHub',
        'desc': desc_match.group(1) if desc_match else '一站式跨境电商服务平台',
        'og_img': og_img.group(1) if og_img else BASE_URL + '/og-image.jpg'
    }

fixed_count = 0
for f in files_need_twitter:
    with open(f, 'r', encoding='utf-8') as fh:
        content = fh.read()
    
    if 'twitter:card' in content:
        continue
    
    meta = extract_meta(f)
    
    twitter_tags = f"""<meta name="twitter:card" content="summary_large_image"/>
<meta name="twitter:title" content="{meta['title']}"/>
<meta name="twitter:description" content="{meta['desc']}"/>
<meta name="twitter:image" content="{meta['og_img']}"/>"""
    
    # 找到 og:image 后面插入
    og_pos = content.find('og:image')
    if og_pos > -1:
        insert_pos = content.find('/>', og_pos) + 2
        content = content[:insert_pos] + '\n' + twitter_tags + content[insert_pos:]
        with open(f, 'w', encoding='utf-8') as fh:
            fh.write(content)
        fixed_count += 1
        print(f'[FIXED] {f} - Twitter Card added')
    else:
        print(f'[WARN] {f} - og:image not found, skipping')

print(f'\nDone! Fixed {fixed_count} files.')
