import os
import re

workspace = r'D:\workspace'
html_files = [f for f in os.listdir(workspace) if f.endswith('.html')]

# 正确的CSS结构：桌面端 .nav-links 应该是 display:flex
# 需要删除不在 @media 内的 display:none 规则

def fix_nav_css(content):
    """修复导航栏CSS，确保桌面端显示，移动端隐藏"""
    
    # 查找所有 .nav-links{display:none...} 不在 @media 内的规则
    # 这通常是错误添加的移动样式
    
    # 方法：找到 <style> 标签，清理重复的 .nav-links 规则
    style_start = content.find('<style>')
    style_end = content.find('</style>')
    
    if style_start == -1 or style_end == -1:
        return content
    
    css = content[style_start+7:style_end]
    
    # 删除不在 @media 内的 .nav-links{display:none...} 规则
    # 这个正则匹配不在 @media 块内的 .nav-links{display:none...}
    # 更简单的方法：查找独立的 .nav-links{display:none 规则并删除
    
    # 查找是否有在 @media 外的 .nav-links{display:none}
    lines = css.split('\n')
    in_media = False
    media_depth = 0
    cleaned_lines = []
    skip_next = False
    
    for i, line in enumerate(lines):
        stripped = line.strip()
        
        if skip_next:
            skip_next = False
            continue
        
        if '@media' in stripped and '{' in stripped:
            in_media = True
            media_depth = stripped.count('{')
        elif in_media:
            media_depth += stripped.count('{') - stripped.count('}')
            if media_depth <= 0:
                in_media = False
        
        # 如果在 @media 外，且包含 .nav-links{display:none 或 .nav-links.open{display:flex
        if not in_media and '.nav-links' in stripped and ('display:none' in stripped or 'display:flex' in stripped):
            # 检查这是否是桌面端样式（应该保留 display:flex;gap:2px 这种）
            if 'gap:2px' in stripped or 'flex-wrap:wrap' in stripped:
                cleaned_lines.append(line)
            elif '.nav-links.open' in stripped:
                # 这是移动菜单开关，如果在 @media 外，删除
                continue
            elif 'position:absolute' in stripped or 'top:54px' in stripped:
                # 这是移动样式，如果在 @media 外，删除
                continue
            elif 'display:none' in stripped and 'position:absolute' not in stripped:
                # 可能是错误的移动端样式，删除
                continue
            else:
                cleaned_lines.append(line)
        else:
            cleaned_lines.append(line)
    
    cleaned_css = '\n'.join(cleaned_lines)
    
    # 确保桌面端 .nav-links 有正确的样式
    if '.nav-links{display:flex' not in cleaned_css:
        # 在第一个 .nav-links 出现的位置添加桌面样式
        nav_links_pos = cleaned_css.find('.nav-links')
        if nav_links_pos == -1:
            # 没有 .nav-links 样式，添加一个
            cleaned_css = '.nav-links{display:flex;gap:2px;flex-wrap:wrap}\n' + cleaned_css
        else:
            # 在现有 .nav-links 规则的位置确保有 display:flex
            pass  # 保持现状
    
    # 确保有 @media(max-width:768px) 块包含移动端样式
    if '@media(max-width:768px)' not in cleaned_css:
        mobile_css = '''
@media(max-width:768px){
.nav-links{display:none;position:absolute;top:54px;left:0;right:0;background:var(--p);flex-direction:column;padding:8px 16px;box-shadow:0 6px 16px rgba(0,0,0,.3)}
.nav-links.open{display:flex}
.nav-links a{padding:12px 8px;border-bottom:1px solid rgba(255,255,255,.08);font-size:.9rem}
.nav-toggle{display:block}
}
'''
        cleaned_css = cleaned_css + mobile_css
    
    new_content = content[:style_start+7] + cleaned_css + content[style_end:]
    return new_content

modified = 0
errors = 0

for fname in html_files:
    fpath = os.path.join(workspace, fname)
    try:
        with open(fpath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 检查是否有 .nav-links 样式
        if '.nav-links' not in content:
            print(f'Skipped: {fname} (no .nav-links)')
            continue
        
        new_content = fix_nav_css(content)
        
        if new_content != content:
            with open(fpath, 'w', encoding='utf-8') as f:
                f.write(new_content)
            modified += 1
            print(f'Fixed: {fname}')
        else:
            print(f'No changes: {fname}')
    except Exception as e:
        errors += 1
        print(f'Error {fname}: {e}')

print(f'\nDone! Modified: {modified}, Errors: {errors}')
