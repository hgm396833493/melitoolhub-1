#!/usr/bin/env python3
"""
Fix remaining edge cases after add_auth_community.py:
1. 404.html - different nav structure
2. Article pages - simple nav (logo + back link)
3. cooperation.html - encoding issue
"""

import os
import re

WORKSPACE = r'D:\workspace'

NAV_AUTH_BUTTONS_SIMPLE = """<div class="nav-auth-btns" id="nav-auth-btns" style="margin-left:auto;display:flex;align-items:center;gap:8px">
<button class="nav-btn-login" id="nav-btn-login" data-i18n="btn_login">登录</button>
<button class="nav-btn-register" id="nav-btn-register" data-i18n="btn_register">注册</button>
<div class="nav-user-info" id="nav-user-info" style="display:none">
<div class="nav-user-avatar" id="nav-user-avatar">?</div>
<span class="nav-user-name" id="nav-user-name"></span>
<div class="nav-user-dropdown" id="nav-user-dropdown">
<a href="#" id="nav-my-comments" data-i18n="nav_my_profile">我的主页</a>
<button class="logout-btn" id="nav-logout" data-i18n="btn_logout">退出登录</button>
</div>
</div>
</div>"""

def fix_404():
    """404.html has nav-links but no nav-actions. Insert auth buttons before </nav>."""
    fpath = os.path.join(WORKSPACE, '404.html')
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()

    if 'nav-auth-btns' in content and '<div class="nav-auth-btns"' in content:
        print('404.html: already has auth buttons, skip')
        return False

    # Insert auth buttons before </nav> in 404.html
    nav_end = content.find('</nav>')
    if nav_end > 0:
        # Also add nav_community link
        if 'nav_community' not in content:
            # Find privacy link in nav-links and add community after it
            if '<a href="/privacy.html"' in content:
                content = content.replace(
                    '<a href="/privacy.html" data-i18n="nav-privacy">隐私</a>',
                    '<a href="/privacy.html" data-i18n="nav-privacy">隐私</a>\n    <a href="/#community" data-i18n="nav_community">用户交流</a>',
                    1
                )

        content = content[:nav_end] + '\n' + NAV_AUTH_BUTTONS_SIMPLE + '\n' + content[nav_end:]
        with open(fpath, 'w', encoding='utf-8') as f:
            f.write(content)
        print('404.html: FIXED')
        return True
    return False

def fix_article_pages():
    """Article pages have simple nav: <nav><div class="nav-logo">...</div><a href="index.html" class="nav-back">...</a></nav>"""
    article_files = [f for f in os.listdir(WORKSPACE) if f.startswith('article-') and f.endswith('.html')]
    fixed = 0
    for fname in article_files:
        fpath = os.path.join(WORKSPACE, fname)
        with open(fpath, 'r', encoding='utf-8') as f:
            content = f.read()

        if '<div class="nav-auth-btns"' in content:
            print(f'{fname}: already has auth buttons, skip')
            continue

        # Fix brand name from MeliToolHub to GlobalTradeHub
        if 'Meli<span>Tool</span>Hub' in content:
            content = content.replace('Meli<span>Tool</span>Hub', 'Global<span>Trade</span>Hub')
        if 'MeliToolHub' in content:
            content = content.replace('MeliToolHub', 'GlobalTradeHub')

        # Insert auth buttons after nav-back link, before </nav>
        # Pattern: <a href="index.html" class="nav-back">...</a></nav>
        pattern = r'(<a href="index\.html" class="nav-back">[^<]*</a>)\s*</nav>'
        m = re.search(pattern, content)
        if m:
            replacement = m.group(1) + '\n' + NAV_AUTH_BUTTONS_SIMPLE + '\n</nav>'
            content = content[:m.start()] + replacement + content[m.end():]
        else:
            print(f'{fname}: WARN - could not find nav-back pattern')
            continue

        with open(fpath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f'{fname}: FIXED (brand + auth buttons)')
        fixed += 1

    return fixed

def fix_cooperation():
    """cooperation.html has UTF-8 encoding issues from git history."""
    fpath = os.path.join(WORKSPACE, 'cooperation.html')
    # Try to read with error handling
    try:
        with open(fpath, 'r', encoding='utf-8') as f:
            content = f.read()
    except UnicodeDecodeError:
        # Read as binary and decode with replacement
        with open(fpath, 'rb') as f:
            raw = f.read()
        # Try to find and fix the bad byte
        content = raw.decode('utf-8', errors='replace')
        print('cooperation.html: decoded with replacement chars')

    if '<div class="nav-auth-btns"' in content:
        print('cooperation.html: already has auth buttons, skip')
        return False

    # Check if the content looks valid enough to modify
    if len(content) < 100:
        print('cooperation.html: content too short, skip')
        return False

    # Try to fix the nav
    if '<a href="index.html" class="nav-logo">' in content:
        # Simple nav structure
        pattern = r'(<a href="index\.html" class="nav-logo">[^<]*</a>.*?)</nav>'
        m = re.search(pattern, content, re.DOTALL)
        if m:
            replacement = m.group(1) + '\n' + NAV_AUTH_BUTTONS_SIMPLE + '\n</nav>'
            content = content[:m.start()] + replacement + content[m.end():]
            with open(fpath, 'w', encoding='utf-8') as f:
                f.write(content)
            print('cooperation.html: FIXED (auth buttons added)')
            return True
    else:
        # Try direct insert before </nav>
        nav_end = content.find('</nav>')
        if nav_end > 0:
            content = content[:nav_end] + '\n' + NAV_AUTH_BUTTONS_SIMPLE + '\n' + content[nav_end:]
            with open(fpath, 'w', encoding='utf-8') as f:
                f.write(content)
            print('cooperation.html: FIXED (auth buttons before </nav>)')
            return True

    print('cooperation.html: could not find nav insertion point')
    return False


def main():
    print('=== Fixing edge cases ===')
    print()

    # 1. Fix 404.html
    fix_404()

    # 2. Fix article pages
    n = fix_article_pages()
    print(f'\nArticle pages fixed: {n}')

    # 3. Fix cooperation.html
    fix_cooperation()

    print('\nDone.')

if __name__ == '__main__':
    main()
