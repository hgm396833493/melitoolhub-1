import os
import re

workspace = r'D:\workspace'
html_files = [f for f in os.listdir(workspace) if f.endswith('.html')]

# 完整的移动端导航CSS（将添加到每个文件的 <style> 标签内）
mobile_nav_css = '''
@media(max-width:768px){
.nav-links{
display:none;
position:absolute;
top:54px;
left:0;
right:0;
background:var(--p);
flex-direction:column;
padding:8px 16px;
box-shadow:0 6px 16px rgba(0,0,0,.3)
}
.nav-links.open{display:flex}
.nav-links a{padding:12px 8px;border-bottom:1px solid rgba(255,255,255,.08);font-size:.9rem}
.nav-toggle{display:block}
}
'''

modified = 0
errors = 0

for fname in html_files:
    fpath = os.path.join(workspace, fname)
    try:
        with open(fpath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 检查是否已经有移动端导航样式
        if '.nav-links.open' in content and '@media(max-width:768px)' in content:
            print(f'Skipped (already has mobile nav): {fname}')
            continue
        
        # 查找 </style> 标签，在它之前插入移动端导航CSS
        style_end = content.find('</style>')
        if style_end > -1:
            # 在 </style> 前插入移动端导航CSS
            before_style_end = content[:style_end]
            after_style_end = content[style_end:]
            
            new_content = before_style_end + mobile_nav_css + after_style_end
            
            with open(fpath, 'w', encoding='utf-8') as f:
                f.write(new_content)
            modified += 1
            print(f'Modified: {fname}')
        else:
            print(f'Error: {fname} has no </style> tag')
            errors += 1
    except Exception as e:
        errors += 1
        print(f'Error {fname}: {e}')

print(f'\nDone! Modified: {modified}, Errors: {errors}')
print('\nNote: Please test the mobile menu by resizing your browser window.')
