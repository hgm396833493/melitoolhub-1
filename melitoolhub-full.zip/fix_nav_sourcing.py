import os
import re

workspace = r'D:\workspace'
html_files = [f for f in os.listdir(workspace) if f.endswith('.html')]

modified = 0
for fname in html_files:
    fpath = os.path.join(workspace, fname)
    try:
        with open(fpath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 替换导航栏中的"采购服务"为"采购代办"
        old_pattern = r'(<a href="#sourcing" data-i18n="nav_sourcing">)采购服务(</a>)'
        new_pattern = r'\1采购代办\2'
        
        if '采购服务' in content and 'nav_sourcing' in content:
            content = re.sub(old_pattern, new_pattern, content)
            with open(fpath, 'w', encoding='utf-8') as f:
                f.write(content)
            modified += 1
            print(f'Modified: {fname}')
        else:
            print(f'Skipped: {fname}')
    except Exception as e:
        print(f'Error {fname}: {e}')

print(f'\nDone! Modified {modified} files')
