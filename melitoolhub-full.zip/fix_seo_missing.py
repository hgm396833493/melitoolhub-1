import os
import re

workspace = r'D:\workspace'
html_files = [f for f in os.listdir(workspace) if f.endswith('.html')]

# Twitter Card 模板
twitter_card = '''<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="GlobalTrade Hub｜跨境贸易一站式平台">
<meta name="twitter:description" content="跨境工具、政策合规、中国采购代办。18语种覆盖全球市场。">
<meta name="twitter:image" content="https://melitoolhub.com/og-image.jpg">
'''

# hreflang 模板（18种语言）
hreflang_tags = '''
<link rel="alternate" hreflang="zh-CN" href="https://melitoolhub.com/">
<link rel="alternate" hreflang="en"    href="https://melitoolhub.com/?lang=en">
<link rel="alternate" hreflang="es"    href="https://melitoolhub.com/?lang=es">
<link rel="alternate" hreflang="pt"    href="https://melitoolhub.com/?lang=pt">
<link rel="alternate" hreflang="ru"    href="https://melitoolhub.com/?lang=ru">
<link rel="alternate" hreflang="fr"    href="https://melitoolhub.com/?lang=fr">
<link rel="alternate" hreflang="de"    href="https://melitoolhub.com/?lang=de">
<link rel="alternate" hreflang="it"    href="https://melitoolhub.com/?lang=it">
<link rel="alternate" hreflang="ar"    href="https://melitoolhub.com/?lang=ar">
<link rel="alternate" hreflang="tr"    href="https://melitoolhub.com/?lang=tr">
<link rel="alternate" hreflang="vi"    href="https://melitoolhub.com/?lang=vi">
<link rel="alternate" hreflang="th"    href="https://melitoolhub.com/?lang=th">
<link rel="alternate" hreflang="id"    href="https://melitoolhub.com/?lang=id">
<link rel="alternate" hreflang="ms"    href="https://melitoolhub.com/?lang=ms">
<link rel="alternate" hreflang="ko"    href="https://melitoolhub.com/?lang=ko">
<link rel="alternate" hreflang="ja"    href="https://melitoolhub.com/?lang=ja">
<link rel="alternate" hreflang="pl"    href="https://melitoolhub.com/?lang=pl">
<link rel="alternate" hreflang="nl"    href="https://melitoolhub.com/?lang=nl">
<link rel="alternate" hreflang="x-default" href="https://melitoolhub.com/">
'''

modified = 0
errors = 0

for fname in html_files:
    fpath = os.path.join(workspace, fname)
    try:
        with open(fpath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        changes = 0
        
        # 1. 添加 Twitter Card（如果缺失）
        if 'twitter:card' not in content:
            # 在 Open Graph 后添加 Twitter Card
            og_end = content.find('</meta>', content.find('og:image')) + 9
            if og_end > 8:
                content = content[:og_end] + '\n' + twitter_card.strip() + '\n' + content[og_end:]
                changes += 1
        
        # 2. 添加 hreflang（如果缺失）
        if 'hreflang' not in content:
            # 在 canonical 后添加 hreflang
            canonical_end = content.find('</link>', content.find('rel="canonical"')) + 8
            if canonical_end > 7:
                content = content[:canonical_end] + hreflang_tags + content[canonical_end:]
                changes += 1
        
        if changes > 0:
            with open(fpath, 'w', encoding='utf-8') as f:
                f.write(content)
            modified += 1
            print(f'Fixed: {fname} (changes: {changes})')
        else:
            print(f'OK: {fname}')
    except Exception as e:
        errors += 1
        print(f'Error {fname}: {e}')

print(f'\nDone! Modified: {modified}, Errors: {errors}')
