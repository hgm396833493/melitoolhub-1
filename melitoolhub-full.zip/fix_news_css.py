import os

workspace = r'D:\workspace'
files_to_fix = ['news1.html', 'news2.html']

# 移动端导航CSS
mobile_nav_css = '''
<style>
@media(max-width:768px){
.nav-links{
display:none;
position:absolute;
top:54px;
left:0;
right:0;
background:var(--p);
flex-direction:column;
padding:8px 16px;
box-shadow:0 6px 16px rgba(0,0,0,.3)
}
.nav-links.open{display:flex}
.nav-links a{padding:12px 8px;border-bottom:1px solid rgba(255,255,255,.08);font-size:.9rem}
.nav-toggle{display:block}
}
</style>
'''

modified = 0
errors = 0

for fname in files_to_fix:
    fpath = os.path.join(workspace, fname)
    try:
        with open(fpath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 在 </head> 前插入 <style> 标签
        if '</head>' in content:
            content = content.replace('</head>', mobile_nav_css + '\n</head>')
            
            with open(fpath, 'w', encoding='utf-8') as f:
                f.write(content)
            modified += 1
            print(f'Modified: {fname}')
        else:
            print(f'Error: {fname} has no </head> tag')
            errors += 1
    except Exception as e:
        errors += 1
        print(f'Error {fname}: {e}')

print(f'\nDone! Modified: {modified}, Errors: {errors}')
