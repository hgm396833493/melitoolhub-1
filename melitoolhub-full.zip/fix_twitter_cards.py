import os
import re
from datetime import datetime

BASE_URL = 'https://melitoolhub.com'

# 为缺少 Twitter Card 的文件添加
files_need_twitter = [
    'article-brazil-market.html', 'article-latam-packaging.html', 'article-latam-products.html',
    'article-meli-ads.html', 'article-mexico-customs.html', 'article-overseas-warehouse.html',
    'article-payment-comparison.html', 'article-tiktok-latam.html', 'cooperation.html',
    'policy-template.html', 'privacy.html', 'sourcing.html', 'tools.html'
]

def extract_meta(file):
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()
    title_match = re.search(r'<title>([^<]+)</title>', content)
    desc_match = re.search(r'<meta[^>]*name="description"[^>]*content="([^"]+)"', content)
    return {
        'title': title_match.group(1) if title_match else 'GlobalTradeHub',
        'desc': desc_match.group(1) if desc_match else '一站式跨境电商服务平台',
    }

fixed_count = 0
for f in files_need_twitter:
    with open(f, 'r', encoding='utf-8') as fh:
        content = fh.read()
    
    if 'twitter:card' in content:
        continue
    
    meta = extract_meta(f)
    
    twitter_tags = f"""<meta name="twitter:card" content="summary_large_image"/>
<meta name="twitter:title" content="{meta['title']}"/>
<meta name="twitter:description" content="{meta['desc']}"/>
<meta name="twitter:image" content="{BASE_URL}/og-image.jpg"/>"""
    
    # 找到 og:site_name 或 og:url 后面插入
    insert_pos = -1
    for marker in ['og:site_name', 'og:url', 'og:type']:
        pos = content.find(marker)
        if pos > -1:
            insert_pos = content.find('>', pos) + 1
            break
    
    if insert_pos > 1:
        content = content[:insert_pos] + '\n' + twitter_tags + content[insert_pos:]
        with open(f, 'w', encoding='utf-8') as fh:
            fh.write(content)
        fixed_count += 1
        print(f'[FIXED] {f} - Twitter Card added')
    else:
        print(f'[WARN] {f} - No og tag found, skipping')

print(f'\nDone! Fixed {fixed_count} files.')
