#!/usr/bin/env python3
"""
彻底修复 nav-lang CSS + HTML：
1. 删除所有 .lang-bar / 错误 .nav-lang CSS
2. 插入正确的 .nav-lang CSS（桌面 + 768 + 480 媒体查询）
3. 删除 .lang-bar HTML 块
4. 注入 nav-lang HTML（导航栏内、登录按钮前）
"""
import os, re

WORKSPACE = r'D:\workspace'

# 正确的 nav-lang CSS（桌面）
NAV_LANG_CSS = """/* Nav Language Selector */
.nav-lang{display:flex;align-items:center;gap:4px;margin-right:4px}
.nav-lang label{color:rgba(255,255,255,.7);font-size:.82rem;cursor:pointer}
.nav-lang select{padding:4px 6px;border-radius:5px;border:1px solid rgba(255,255,255,.25);background:rgba(255,255,255,.1);color:#fff;font-size:.78rem;cursor:pointer;outline:none}
.nav-lang select:focus{border-color:var(--a)}
.nav-lang select option{background:var(--p);color:#fff}"""

# 768 媒体查询内的 .nav-lang
NAV_LANG_CSS_768 = """.nav-lang{padding:0;gap:3px}
.nav-lang label{font-size:.72rem}
.nav-lang select{max-width:110px;font-size:.72rem}"""

# 480 媒体查询内的 .nav-lang
NAV_LANG_CSS_480 = """.nav-lang select{max-width:90px;font-size:.7rem}"""

NAV_LANG_HTML = """<!-- Language Selector (in nav) -->
<div class="nav-lang">
<label for="lang-select">🌐</label>
<select id="lang-select" aria-label="切换语言">
<option value="zh">中文</option>
<option value="en">EN</option>
<option value="es">ES</option>
<option value="pt">PT</option>
<option value="ru">RU</option>
<option value="fr">FR</option>
<option value="de">DE</option>
<option value="it">IT</option>
<option value="ar">AR</option>
<option value="tr">TR</option>
<option value="vi">VI</option>
<option value="th">TH</option>
<option value="id">ID</option>
<option value="ms">MS</option>
<option value="ko">KO</option>
<option value="ja">JA</option>
<option value="pl">PL</option>
<option value="nl">NL</option>
</select>
</div>"""


def remove_all_lang_css(content):
    """删除所有 .lang-bar 和 .nav-lang 相关 CSS 规则（含媒体查询）"""
    # 删除 .lang-bar 相关 CSS 行
    lines = content.splitlines()
    out = []
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        # 跳过 .lang-bar 或错误 .nav-lang（含 background / justify-content / flex-wrap 等旧属性）的 CSS 规则
        if '.lang-bar' in stripped:
            # 跳过整个 CSS 规则
            depth = stripped.count('{') - stripped.count('}')
            i += 1
            while i < len(lines) and depth > 0:
                depth += lines[i].count('{') - lines[i].count('}')
                i += 1
            continue
        if '.nav-lang' in stripped and ('background' in stripped or 'justify-content' in stripped or 'flex-wrap' in stripped):
            # 错误 .nav-lang CSS，跳过
            depth = stripped.count('{') - stripped.count('}')
            i += 1
            while i < len(lines) and depth > 0:
                depth += lines[i].count('{') - lines[i].count('}')
                i += 1
            continue
        out.append(line)
        i += 1
    return '\n'.join(out)


def insert_correct_css(content):
    """在 /* Nav */ 注释后插入正确的 .nav-lang CSS"""
    # 先删除已有的正确 .nav-lang CSS（防止重复）
    # 用正则删除 /* Nav Language Selector */ 到下一个 /* 或 </style> 之间的内容
    content = re.sub(
        r'/\* Nav Language Selector \*/.*?(?=/\*|</style>)',
        '',
        content,
        flags=re.DOTALL
    )
    
    # 在 /* Nav */ 后插入正确 CSS
    marker = '/* Nav */'
    if marker in content:
        replacement = marker + '\n' + NAV_LANG_CSS
        content = content.replace(marker, replacement, 1)
    
    # 在 @media(max-width:768px){ 内加入 .nav-lang 规则
    # 找到该媒体查询，在第一个 } 前插入
    pattern_768 = r'(@media\(max-width:768\)\{)'
    m = re.search(pattern_768, content)
    if m:
        # 在该媒体查询内找插入点（在第一个 .nav-search-btn 前或 } 前）
        pos = m.end()
        # 找下一个 }
        depth = 1
        i = pos
        while i < len(content) and depth > 0:
            if content[i] == '{': depth += 1
            if content[i] == '}': depth -= 1
            i += 1
        # 在 } 前插入
        before_close = content[:i-1]
        after_close = content[i-1:]
        nav_lang_768 = '\n' + NAV_LANG_CSS_768 + '\n'
        # 避免重复
        if '.nav-lang{padding:0' not in before_close:
            content = before_close + nav_lang_768 + after_close
    
    # 在 @media(max-width:480px){ 内加入 .nav-lang 规则
    pattern_480 = r'(@media\(max-width:480px\)\{)'
    m = re.search(pattern_480, content)
    if m:
        pos = m.end()
        depth = 1
        i = pos
        while i < len(content) and depth > 0:
            if content[i] == '{': depth += 1
            if content[i] == '}': depth -= 1
            i += 1
        before_close = content[:i-1]
        after_close = content[i-1:]
        nav_lang_480 = '\n' + NAV_LANG_CSS_480 + '\n'
        if '.nav-lang select{max-width:90px' not in before_close:
            content = before_close + nav_lang_480 + after_close
    
    return content


def fix_html(content):
    """删除 .lang-bar HTML，注入 nav-lang HTML"""
    # 1. 删除 .lang-bar 块
    pattern = r'<!-- ===== Language Bar ===== -->\s*<div class="lang-bar">.*?</div>\s*'
    content = re.sub(pattern, '', content, flags=re.DOTALL)
    
    # 2. 如果还没有 nav-lang HTML，注入
    if 'class="nav-lang"' not in content:
        # 插入在 nav-auth-btns 前
        marker = '<div class="nav-auth-btns"'
        if marker in content:
            content = content.replace(marker, NAV_LANG_HTML + '\n' + marker, 1)
        else:
            # 备选：插在 <!-- Auth Buttons --> 前
            marker2 = '<!-- Auth Buttons -->'
            if marker2 in content:
                content = content.replace(marker2, NAV_LANG_HTML + '\n' + marker2, 1)
    
    return content


def process_file(fpath):
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()
    original = content
    
    content = remove_all_lang_css(content)
    content = insert_correct_css(content)
    content = fix_html(content)
    
    if content != original:
        with open(fpath, 'w', encoding='utf-8') as f:
            f.write(content)
        return True
    return False


def main():
    files = sorted([f for f in os.listdir(WORKSPACE) if f.endswith('.html')])
    print(f'Found {len(files)} HTML files')
    print('=' * 50)
    ok = 0
    for fname in files:
        fpath = os.path.join(WORKSPACE, fname)
        try:
            if process_file(fpath):
                print(f'  OK: {fname}')
                ok += 1
            else:
                print(f'  SKIP: {fname}')
        except Exception as e:
            print(f'  ERROR: {fname}: {e}')
    print('=' * 50)
    print(f'Done: {ok}/{len(files)}')

if __name__ == '__main__':
    main()
