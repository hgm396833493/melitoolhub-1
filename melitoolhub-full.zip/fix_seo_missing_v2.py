import os
import re

workspace = r'D:\workspace'
html_files = [f for f in os.listdir(workspace) if f.endswith('.html')]

# Twitter Card 模板
twitter_card = '''<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="GlobalTrade Hub｜跨境贸易一站式平台">
<meta name="twitter:description" content="跨境工具、政策合规、中国采购代办。18语种覆盖全球市场。">
<meta name="twitter:image" content="https://melitoolhub.com/og-image.jpg">
'''

# hreflang 模板（18种语言）
hreflang_tags = '''
<link rel="alternate" hreflang="zh-CN" href="https://melitoolhub.com/">
<link rel="alternate" hreflang="en"    href="https://melitoolhub.com/?lang=en">
<link rel="alternate" hreflang="es"    href="https://melitoolhub.com/?lang=es">
<link rel="alternate" hreflang="pt"    href="https://melitoolhub.com/?lang=pt">
<link rel="alternate" hreflang="ru"    href="https://melitoolhub.com/?lang=ru">
<link rel="alternate" hreflang="fr"    href="https://melitoolhub.com/?lang=fr">
<link rel="alternate" hreflang="de"    href="https://melitoolhub.com/?lang=de">
<link rel="alternate" hreflang="it"    href="https://melitoolhub.com/?lang=it">
<link rel="alternate" hreflang="ar"    href="https://melitoolhub.com/?lang=ar">
<link rel="alternate" hreflang="tr"    href="https://melitoolhub.com/?lang=tr">
<link rel="alternate" hreflang="vi"    href="https://melitoolhub.com/?lang=vi">
<link rel="alternate" hreflang="th"    href="https://melitoolhub.com/?lang=th">
<link rel="alternate" hreflang="id"    href="https://melitoolhub.com/?lang=id">
<link rel="alternate" hreflang="ms"    href="https://melitoolhub.com/?lang=ms">
<link rel="alternate" hreflang="ko"    href="https://melitoolhub.com/?lang=ko">
<link rel="alternate" hreflang="ja"    href="https://melitoolhub.com/?lang=ja">
<link rel="alternate" hreflang="pl"    href="https://melitoolhub.com/?lang=pl">
<link rel="alternate" hreflang="nl"    href="https://melitoolhub.com/?lang=nl">
<link rel="alternate" hreflang="x-default" href="https://melitoolhub.com/">
'''

modified = 0
errors = 0

for fname in html_files:
    fpath = os.path.join(workspace, fname)
    try:
        with open(fpath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        changes = 0
        
        # 1. 添加 Twitter Card（如果缺失）
        if 'twitter:card' not in content:
            # 查找 Open Graph 结束位置
            og_pos = content.find('og:image')
            if og_pos > -1:
                # 找到 og:image 的 </meta> 标签
                meta_end = content.find('>', og_pos)
                if meta_end > -1:
                    # 在 </meta> 后插入 Twitter Card
                    insert_pos = meta_end + 1
                    # 如果不是自闭合，查找 </meta>
                    if not content[meta_end-1] == '/':
                        meta_end = content.find('</meta>', og_pos) + 7
                        insert_pos = meta_end
                    
                    content = content[:insert_pos] + '\n' + twitter_card + content[insert_pos:]
                    changes += 1
        
        # 2. 添加 hreflang（如果缺失）
        if 'hreflang' not in content:
            # 查找 canonical 结束位置
            canonical_pos = content.find('rel="canonical"')
            if canonical_pos > -1:
                # 找到 canonical 的 </link> 或 />
                link_end = content.find('>', canonical_pos)
                if link_end > -1:
                    insert_pos = link_end + 1
                    if not content[link_end-1] == '/':
                        link_end = content.find('</link>', canonical_pos) + 7
                        insert_pos = link_end
                    
                    content = content[:insert_pos] + hreflang_tags + content[insert_pos:]
                    changes += 1
        
        if changes > 0:
            with open(fpath, 'w', encoding='utf-8') as f:
                f.write(content)
            modified += 1
            print(f'Fixed: {fname} (changes: {changes})')
        else:
            print(f'OK: {fname}')
    except Exception as e:
        errors += 1
        print(f'Error {fname}: {e}')

print(f'\nDone! Modified: {modified}, Errors: {errors}')
