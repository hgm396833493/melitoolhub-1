import os
import re

workspace = r'D:\workspace'
html_files = [f for f in os.listdir(workspace) if f.endswith('.html')]

# 要删除的重复移动导航CSS（不在 @media 内的）
orphan_css_pattern = r'\.nav-links\{display:none;position:absolute;top:54px;left:0;right:0;background:var\(--p\);flex-direction:column;padding:8px 16px;box-shadow:0 6px 16px rgba\(0,0,0,\.3\)\}\s*\.nav-links\.open\{display:flex\}\s*\.nav-links a\{padding:12px 8px;border-bottom:1px solid rgba\(255,255,255,\.08\);font-size:\.9rem\}\s*\.nav-toggle\{display:block\}\s*\}'

modified = 0
errors = 0

for fname in html_files:
    fpath = os.path.join(workspace, fname)
    try:
        with open(fpath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 检查是否有不在 @media 内的移动导航样式
        if '.nav-links{display:none;position:absolute' in content:
            # 删除不在 @media 内的移动导航样式
            new_content = re.sub(orphan_css_pattern, '', content)
            
            if new_content != content:
                with open(fpath, 'w', encoding='utf-8') as f:
                    f.write(new_content)
                modified += 1
                print(f'Fixed: {fname}')
            else:
                print(f'No match (pattern): {fname}')
        else:
            print(f'No orphan CSS: {fname}')
    except Exception as e:
        errors += 1
        print(f'Error {fname}: {e}')

print(f'\nDone! Fixed: {modified}, Errors: {errors}')
