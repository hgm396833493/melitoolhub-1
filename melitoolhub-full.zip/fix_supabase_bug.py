import os
import re

SUPABASE_URL = 'https://woiwjttrtokwgrhhzobm.supabase.co'

for f in sorted(os.listdir('.')):
    if not f.endswith('.html'):
        continue

    with open(f, 'r', encoding='utf-8') as fh:
        content = fh.read()

    old = f"SUPABASE_URL==='{SUPABASE_URL}'"
    new = f"SUPABASE_URL!=='{SUPABASE_URL}'"

    if old not in content:
        print(f'[SKIP] {f} - no bug')
        continue

    content = content.replace(old, new)

    with open(f, 'w', encoding='utf-8') as fh:
        fh.write(content)

    print(f'[FIXED] {f}')

print('\nDone! All files fixed.')
